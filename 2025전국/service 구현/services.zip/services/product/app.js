const express = require('express');
const AWS = require('aws-sdk');
const app = express();

app.use(express.json());

const dynamodb = new AWS.DynamoDB.DocumentClient({
  region: process.env.AWS_DEFAULT_REGION
});

app.get('/healthcheck', (req, res) => {
  res.status(200).json({ status: 'healthy' });
});

app.get('/v1/product', async (req, res) => {
  try {
    const params = {
      TableName: process.env.DYNAMODB_TABLE,
      Limit: 1
    };
    await dynamodb.scan(params).promise();
    res.json({ message: 'Product service running', dynamodb: 'connected' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(8080, () => console.log('Product service on port 8080'));