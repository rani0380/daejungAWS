const express = require('express');
const app = express();

app.use(express.json());

app.get('/healthcheck', (req, res) => {
  res.status(200).json({ status: 'healthy' });
});

app.get('/v1/stress', (req, res) => {
  const start = Date.now();
  while (Date.now() - start < 100) {} // 100ms CPU 부하
  res.json({ message: 'Stress test completed', duration: '100ms' });
});

app.listen(8080, () => console.log('Stress service on port 8080'));